const mypackage = require("package-vamika");
console.log(mypackage);