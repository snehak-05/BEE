function suspend(studentName){
    //let principal = new Principal("Sneha");
    //let principal2 = new Principal("Siman");
    let principal = Principal.getPrincipal();
    Principal.suspend(studentName);
}
function notify(){
    //let principal = new Principal("Kundu");
    let principal=Principal.getPrincipal();
    //principal.notify("school band rhenge ab nachoo")
}