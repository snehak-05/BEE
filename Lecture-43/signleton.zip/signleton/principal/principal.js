class Principal{
    multipleSchool = new Map()//using hashmap
    _principal=null
    _constructor(name){
        this.principal=name
    }
    static getPrincipal(school){
        if(!multipleSchool.has(school)){
            let principal = new Principal();
            multipleSchool.set(school, principal)
        }
        return multipleSchool.get(school);
    }
    createCurriculam(){

    }
    resticateStudents(){

    }
    suspendStudent(days){

    }
    notify(message){

    }
}
mpdule.exports=Principal;