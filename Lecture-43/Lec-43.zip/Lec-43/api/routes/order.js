const express = require("express");
const router = express.Router();
const OrderBook = require("../service/order");
const { postPlaceOrder, gerOrderbook, getRecentTrades } = require("../controller/order");
router.post("/order", postPlaceOrder)
router.get("/trades", gerOrderbook)
router.get("/depth", getRecentTrades)

let ob = new OrderBook("BTCUSD");

router.post("/", async (req, res) => {
    try {
        const { side, type, price, quantity, user } = req.body;
        const response = ob.placeOrder(side, type, price, quantity, user);
        res.status(200).json({
            message: "Order placed successfully",
            order: response,
            book: ob.getBookSnapShot()
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

module.exports = router;
