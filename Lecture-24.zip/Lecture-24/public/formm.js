 //signup feature

// const { application } = require("express")

let signupForm=document.querySelector("#sigup-form")
let signupName=document.querySelector("#signup-name")
let signupEmail=document.querySelector("#signup-email")
let signupPassword=document.querySelector("#signup-password")

signupForm.addEventListener("submit",async function(e){
    e.preventDefault();
    console.log("121121212121212")
    let nameValue=signupName.value;
    let emailValue=signupEmail.value;
    let passwordValue=signupPassword.value;
    let response = await fetch("/users",{
        method:"POST",
        body:JSON.stringify({name:nameValue,email:emailValue,password:passwordValue}),
        headers:{
            "content-type":"application/json"
        }
    })
    let data=await response.json();
    console.log(data)
})