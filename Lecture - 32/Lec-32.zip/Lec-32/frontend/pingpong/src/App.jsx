

function App() {
  let [ws, setWs] = useState(null)

  useEffect(()=>{ //useEffect --> hook use to do side-Effect in react
    const socket = new WebSocket("wss://localhost:8888");
    socket.onmessage(function(message){
      console.log(message);
    })
  },[])
  function sendMessage(){
    let message = inputRef.current.value
    ws.send(message)
    inputRef.current.value=""
  }
  return (
    <>
      <h1>Ping Pong</h1>
      <input type="text"/>
      <button onClick={sendMessage}>Send</button>
    </>
  )
}

export default App
