export function sum(a,b) {
    return a+b
}
export function sub(a,b) {
    return a-b
}

function multiply(a,b) {
    return a*b
}
export default multiply