const file1 = require("./File1")
const file2 = require("./File2")

console.log (file1);
console.log (file2);