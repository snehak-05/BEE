let somefun = require("./Index");
console.log (somefun);

let res1 = somefun.sum(3,2);
let res2 = somefun.sub(6,5);
console.log (res1,res2)