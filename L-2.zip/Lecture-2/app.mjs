import {sum,sub} from "./File.mjs";
import multiply from "./File.mjs";
console.log (sum,sub);
console.log (multiply);