function sum(a,b) {
    return a+b;
}
function sub(a,b) {
    return a-b;
}
module.exports = {
    sum, sub
}